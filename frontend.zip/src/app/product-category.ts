export class ProductCategory {
	category_id: number;
	category_name:string;
	category_type:number;
	create_time:Date;
	update_time:Date;
}
