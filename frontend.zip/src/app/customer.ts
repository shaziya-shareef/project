export class Customer {
	id: number;
	active:boolean;
	password:string;
	email:string;
	phone:string;
	name:string;
	address:string;
	role:string;
}
