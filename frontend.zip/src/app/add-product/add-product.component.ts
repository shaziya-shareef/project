import { Component, OnInit } from '@angular/core';
import { ProductInfo } from '../product-info';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {
	product = new ProductInfo();
	submitted = false;

  constructor(private loginService: LoginService, private router: Router) { }

  ngOnInit() {

  }

  newProduct() : void{
  	this.submitted = false;
  	this.product = new ProductInfo();
  }

  save(){
  	this.loginService.createProduct(this.product)
  	.subscribe(data => console.log(data),error => console.log(error));
  	this.product=new ProductInfo();
  	this.gotoList();
  }

  onSubmit(){
  	this.submitted=true;
  	this.save();
  }

  gotoList(){
  	this.router.navigate(['addproduct']);
  }

}
