package com.example.minilogin.model;

public class Customer {
	private int id;
	private boolean active;
	private String password;
	private String email;
	private long phone;
	private String name;
	private String role;
	private String address;
	
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public Customer() {
		super();
	}
	
	public Customer(int id, boolean active, String password, String email, long phone, String name, String role,
			String address) {
		this.id = id;
		this.active = active;
		this.password = password;
		this.email = email;
		this.phone = phone;
		this.name = name;
		this.role = role;
		this.address = address;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", active=" + active + ", password=" + password + ", email=" + email + ", phone="
				+ phone + ", name=" + name + ", role=" + role + ", address=" + address + "]";
	}

	
	

}
