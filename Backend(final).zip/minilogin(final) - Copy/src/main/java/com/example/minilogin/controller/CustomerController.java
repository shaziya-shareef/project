package com.example.minilogin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.minilogin.DAO.CustomerDAO;
import com.example.minilogin.DAOimpl.CustomerDaoImpl;
import com.example.minilogin.model.Customer;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class CustomerController {
	
	@Autowired
	private CustomerDAO customerDAO;
	
	@GetMapping("/Customer")
	public List getCustomers() {	
	return customerDAO.viewAllCustomer();
}

	
	@GetMapping("/Customer/{email}/{password}")
	public ResponseEntity getCustomerLogin(@PathVariable("email") String email,@PathVariable("password") String password) {		
		int flag=customerDAO.loginValidation(email,password);			
		if (flag == 0) {
			return new ResponseEntity("No Customer found for ID " + email, HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity(flag, HttpStatus.OK);
	}
	
	@PostMapping(value = "/post/customer")
	public ResponseEntity addCustomer(@RequestBody Customer customer) {
		customerDAO.addCustomer(customer);
		return new ResponseEntity(customer, HttpStatus.OK);
	}

}
