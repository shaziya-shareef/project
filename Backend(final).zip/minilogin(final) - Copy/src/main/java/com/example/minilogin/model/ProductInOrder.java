package com.example.minilogin.model;

public class ProductInOrder {

}
